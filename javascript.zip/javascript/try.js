// const listItems=function(items){
// items.forEach(function(item){
// console.log(item)
//     })
// }
// const items=["milk","coffe"]
// listItems(items)

// console.log("hi")

// setTimeout(function(){
//     console.log("hhhii") 
// },2000);

// console.log("exit")


// const listItems=function(items){
//     items.forEach(function(item){
//         console.log(item);
//     })
// }
// const items=["hhhhh"]
// listItems(items)

// const express=require('express')
// const app=express()

// app.get("/",(req,res)=>{
//     res.send("hello ")
// })

const express=require('express')
const add=express()

app.get("/",(res,req)=>{
    req.send("gfdfdf")
})
app.post("/",(res,req)=>{
    req.send("gfdfdf")
})
app.all("/secret",(res,req,next)=>{
    console.log("gfdfdf")
})