// const getColour=()=>{

//     const randomNumber=Math.floor(Math.random()*16777215);
//     const randomCode="#"+randomNumber.toString(16);
//     document.body.style.background=randomCode;
//     document.getElementById("colour-code").innerHTML=randomCode;

//     navigator.clipboard.writeText(randomCode)
// }

// document.getElementById("btn").addEventListener(
//     "click",
//      getColour
    
// )
// getColour();


const getColour=()=>{
 

    const randomNumber=Math.floor(Math.random()*16777215);
    const randomCode="#"+randomNumber.toString(16);
    document.body.style.background=randomCode;
    document.getElementById("colour-code").innerHTML=randomCode;

}

document.getElementById("btn").addEventListener(
    "click",
    getColour
)

getColour();



